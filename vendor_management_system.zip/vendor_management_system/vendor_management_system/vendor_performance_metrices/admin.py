from django.contrib import admin
from .models import HistoricalPerformance


#model Register
admin.site.register(HistoricalPerformance)